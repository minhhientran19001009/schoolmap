<template>
  <div>
    <!-- Backdrop overlay: focus the school profile on every screen size -->
    <div 
      v-if="school"
      @click="$emit('close')"
      class="fixed inset-0 z-[1190] bg-slate-900/35 backdrop-blur-[1.5px] animate-in fade-in duration-200">
    </div>

    <!-- Main Right Sidebar Drawer -->
    <div 
      v-if="school"
      class="fixed top-0 right-0 bottom-0 z-[1200] w-full sm:w-[640px] lg:w-[760px] xl:w-[900px] 2xl:w-[980px] bg-white shadow-[-10px_0_30px_rgba(0,0,0,0.15)] flex flex-col border-l border-slate-200 transition-all duration-300 ease-in-out select-none">
      
      <!-- Top Header (Inspired by reference screenshot) -->
      <div class="relative bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white p-4 sm:p-5 flex-shrink-0 shadow-md">
        <!-- Close Button -->
        <button 
          @click="$emit('close')"
          class="absolute top-4 right-4 text-white/80 hover:text-white bg-white/10 hover:bg-white/20 w-8 h-8 rounded-full flex items-center justify-center transition-all cursor-pointer z-10"
          title="Đóng ngăn chi tiết">
          <i class="fa-solid fa-xmark text-sm"></i>
        </button>

        <!-- Top Badge row -->
        <div class="flex items-center gap-2 mb-2">
          <div class="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center flex-shrink-0">
            <i :class="levelIcon" class="text-xs text-white"></i>
          </div>
          <span class="text-[11px] font-bold uppercase tracking-wider text-blue-100">
            {{ levelLabel || 'CƠ SỞ GIÁO DỤC - ĐÀO TẠO' }}
          </span>
        </div>

        <!-- School Title -->
        <h2 class="text-base sm:text-lg font-bold leading-snug pr-10 text-white">
          {{ school.name }}
        </h2>

        <div v-if="school.code" class="mt-1.5 inline-flex items-center gap-1.5 text-[11px] text-blue-100">
          <span class="text-blue-200">Mã trường:</span>
          <span class="rounded bg-white/15 px-1.5 py-0.5 font-mono font-semibold tracking-wide text-white">{{ school.code }}</span>
        </div>

        <!-- Status & Location tags -->
        <div class="flex flex-wrap items-center gap-1.5 mt-2.5 text-xs">
          <!-- Active Status Pill -->
          <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/25 text-emerald-200 border border-emerald-400/30">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Hoạt động</span>
          </span>

          <!-- Location Badge -->
          <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-white/15 text-white/90 border border-white/20">
            <i class="fa-solid fa-location-dot text-[10px] text-blue-200"></i>
            <span>{{ school.ward || school.district_name || 'Ninh Bình' }}</span>
          </span>
        </div>
      </div>

      <!-- Tab Navigation (3 Clean Tabs: Tổng quan, Số liệu, Doanh nghiệp) -->
      <div class="flex border-b border-slate-200 bg-slate-50/80 px-2 flex-shrink-0 text-xs font-semibold">
        <!-- Tab 1: Tổng quan -->
        <button 
          @click="activeTab = 'general'"
          :class="activeTab === 'general' 
            ? 'text-blue-700 border-b-2 border-blue-700 bg-white shadow-xs font-bold' 
            : 'text-slate-600 hover:text-slate-900'"
          class="flex-1 py-3 px-2 text-center transition-all flex items-center justify-center gap-1.5 cursor-pointer">
          <i class="fa-solid fa-circle-info text-xs"></i>
          <span>Tổng quan</span>
        </button>

        <!-- Tab 2: Số liệu -->
        <button 
          @click="activeTab = 'personnel'"
          :class="activeTab === 'personnel' 
            ? 'text-blue-700 border-b-2 border-blue-700 bg-white shadow-xs font-bold' 
            : 'text-slate-600 hover:text-slate-900'"
          class="flex-1 py-3 px-2 text-center transition-all flex items-center justify-center gap-1.5 cursor-pointer">
          <i class="fa-solid fa-chart-column text-xs"></i>
          <span>Số liệu</span>
        </button>

        <!-- Tab 3: Doanh nghiệp -->
        <button 
          @click="activeTab = 'enterprises'"
          :class="activeTab === 'enterprises' 
            ? 'text-blue-700 border-b-2 border-blue-700 bg-white shadow-xs font-bold' 
            : 'text-slate-600 hover:text-slate-900'"
          class="flex-1 py-3 px-2 text-center transition-all flex items-center justify-center gap-1.5 cursor-pointer">
          <i class="fa-solid fa-handshake text-xs"></i>
          <span>Doanh nghiệp</span>
        </button>
      </div>

      <!-- Tab Content Area (Scrollable) -->
      <div class="flex-1 overflow-y-auto p-4 space-y-4 text-xs text-slate-700 bg-slate-50/30">
        
        <!-- ============================================================== -->
        <!-- TAB 1: TỔNG QUAN & ĐÀO TẠO                                    -->
        <!-- ============================================================== -->
        <div v-if="activeTab === 'general'" class="space-y-4 animate-in fade-in duration-200">
          
          <!-- 0. Thông tin liên hệ & Website trường -->
          <div class="bg-white rounded-xl p-3.5 border border-slate-200 shadow-xs space-y-2">
            <div class="font-bold text-slate-800 text-xs flex items-center justify-between">
              <span class="flex items-center gap-1.5">
                <i class="fa-solid fa-address-card text-indigo-600"></i>
                <span>Thông tin liên hệ & Website</span>
              </span>
              <a 
                v-if="school.website"
                :href="school.website.startsWith('http') ? school.website : `https://${school.website}`"
                target="_blank"
                rel="noopener noreferrer"
                class="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-50 text-blue-700 hover:bg-blue-100 font-semibold text-[11px] transition-colors">
                <i class="fa-solid fa-globe text-blue-600"></i>
                <span>Truy cập Website</span>
                <i class="fa-solid fa-arrow-up-right-from-square text-[8px]"></i>
              </a>
            </div>

            <div class="space-y-1.5 pt-1 text-[11.5px]">
              <div v-if="school.address" class="flex items-start gap-2 text-slate-600">
                <i class="fa-solid fa-location-dot text-slate-400 mt-0.5 w-4 text-center flex-shrink-0"></i>
                <span class="leading-snug">{{ school.address }}</span>
              </div>

              <div v-if="school.phone" class="flex items-center gap-2 text-slate-600">
                <i class="fa-solid fa-phone text-slate-400 w-4 text-center flex-shrink-0"></i>
                <a :href="`tel:${school.phone}`" class="text-blue-700 font-semibold hover:underline">
                  {{ school.phone }}
                </a>
              </div>

              <div v-if="school.website" class="flex items-center gap-2 text-slate-600 truncate">
                <i class="fa-solid fa-link text-slate-400 w-4 text-center flex-shrink-0"></i>
                <a 
                  :href="school.website.startsWith('http') ? school.website : `https://${school.website}`"
                  target="_blank"
                  rel="noopener noreferrer"
                  class="text-blue-600 hover:underline truncate">
                  {{ school.website }}
                </a>
              </div>
            </div>
          </div>

          <!-- Related campuses network -->
          <div v-if="relatedCampuses.length > 1" class="bg-white rounded-xl p-3.5 sm:p-4 border border-slate-200 shadow-xs space-y-3">
            <!-- Header with Title and Count -->
            <div class="flex items-center justify-between pb-2.5 border-b border-slate-100">
              <div class="flex items-center gap-2">
                <div class="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center flex-shrink-0">
                  <i class="fa-solid fa-network-wired text-xs"></i>
                </div>
                <div>
                  <h3 class="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                    <span>Hệ thống cơ sở đào tạo</span>
                  </h3>
                  <p class="text-[10.5px] text-slate-400 font-normal">
                    {{ mainCampusesCount }} trụ sở chính · {{ subCampusesCount }} cơ sở trực thuộc
                  </p>
                </div>
              </div>
              
              <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700">
                {{ relatedCampuses.length }}
              </span>
            </div>

            <!-- Mini search filter if > 4 campuses -->
            <div v-if="relatedCampuses.length > 4" class="relative">
              <i class="fa-solid fa-magnifying-glass absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 text-[10px]"></i>
              <input
                v-model="campusSearchQuery"
                type="text"
                placeholder="Lọc theo tên cơ sở, phường xã..."
                class="w-full pl-7 pr-7 py-1 rounded-lg border border-slate-200 bg-slate-50/70 text-[11px] text-slate-700 focus:outline-hidden focus:bg-white focus:border-indigo-400 focus:ring-1 focus:ring-indigo-400 transition-all placeholder:text-slate-400"
              />
              <button
                v-if="campusSearchQuery"
                @click="campusSearchQuery = ''"
                class="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer">
                <i class="fa-solid fa-xmark"></i>
              </button>
            </div>

            <!-- Campus Items List -->
            <div :class="relatedCampuses.length > 4 ? 'max-h-[340px] overflow-y-auto pr-1' : ''" class="space-y-2">
              <div v-if="filteredCampuses.length === 0" class="py-4 text-center text-slate-400 text-[11px] italic">
                Không tìm thấy cơ sở phù hợp
              </div>

              <button
                v-for="campus in filteredCampuses"
                :key="campus.id"
                type="button"
                :disabled="campus.is_current"
                @click="$emit('view-related-campus', campus)"
                :class="campus.is_current
                  ? 'bg-gradient-to-r from-blue-50/90 via-indigo-50/40 to-white border-blue-400 shadow-xs ring-1 ring-blue-500/20 cursor-default'
                  : 'bg-white hover:bg-slate-50/90 border-slate-200 hover:border-indigo-300 hover:shadow-xs cursor-pointer group'"
                class="w-full text-left px-3.5 py-2.5 rounded-xl border transition-all duration-200 relative overflow-hidden disabled:opacity-100">
                
                <!-- Left Accent indicator bar for active item -->
                <div v-if="campus.is_current" class="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-blue-600 to-indigo-600 rounded-l-xl"></div>

                <div class="flex items-center justify-between gap-2.5">
                  <!-- Content details (clean name without logo or type tags) -->
                  <div class="min-w-0 flex-1">
                    <!-- Title row -->
                    <div>
                      <span 
                        :class="campus.is_current ? 'text-blue-950 font-bold' : 'text-slate-800 group-hover:text-indigo-700 font-semibold'"
                        class="text-xs sm:text-[13px] truncate transition-colors">
                        {{ getCampusDisplayName(campus) }}
                      </span>
                    </div>

                    <!-- Ward & Address info -->
                    <div class="mt-1 flex items-center gap-1.5 flex-wrap text-[11px] text-slate-500">
                      <!-- Ward Chip -->
                      <span v-if="campus.ward" class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-700 border border-slate-200/60 flex-shrink-0">
                        <i class="fa-solid fa-location-dot text-[8.5px] text-indigo-500"></i>
                        <span>{{ campus.ward }}</span>
                      </span>

                      <!-- Short Address -->
                      <span v-if="campus.address" class="truncate text-slate-500 text-[10.5px]" :title="campus.address">
                        {{ campus.address }}
                      </span>
                    </div>
                  </div>

                  <!-- Right Action Indicator -->
                  <div v-if="!campus.is_current" class="flex-shrink-0 self-center pl-1 text-slate-300 group-hover:text-indigo-600 transition-colors">
                    <div class="w-6 h-6 rounded-full flex items-center justify-center bg-slate-50 group-hover:bg-indigo-50 transition-colors">
                      <i class="fa-solid fa-arrow-right text-[10px] group-hover:translate-x-0.5 transition-transform"></i>
                    </div>
                  </div>
                  <div v-else class="flex-shrink-0 self-center pl-1 text-blue-600">
                    <i class="fa-solid fa-circle-check text-sm"></i>
                  </div>
                </div>
              </button>
            </div>
          </div>

          <!-- 1. Danh sách Ban Giám hiệu, Trưởng khoa -->
          <div class="bg-white rounded-xl p-3.5 border border-slate-200 shadow-xs">
            <div class="flex items-center justify-between mb-2.5">
              <span class="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <i class="fa-solid fa-user-tie text-blue-600"></i>
                <span>Ban Giám hiệu & Lãnh đạo</span>
              </span>
              <span class="text-[10px] text-slate-400 font-medium">
                {{ displayLeaders.length }} cán bộ
              </span>
            </div>

            <div v-if="displayLeaders.length > 0" class="space-y-2">
              <div 
                v-for="(leader, idx) in displayLeaders" 
                :key="idx"
                class="flex items-center justify-between p-2 rounded-lg bg-slate-50/80 border border-slate-100 hover:border-blue-200 transition-colors">
                <div class="flex items-center gap-2.5">
                  <div class="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs flex-shrink-0">
                    {{ leader.name ? leader.name.charAt(0) : 'L' }}
                  </div>
                  <div>
                    <div class="font-bold text-slate-800 text-[12px]">{{ leader.name }}</div>
                    <div class="text-[11px] text-blue-600 font-medium">{{ leader.position }}</div>
                  </div>
                </div>
                <span class="text-[10px] px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-semibold">
                  Lãnh đạo
                </span>
              </div>
            </div>
            <div v-else class="text-[11px] text-slate-400 italic text-center py-2">
              Đang cập nhật thông tin Ban Giám hiệu
            </div>
          </div>



          <!-- 3. Thông tin đào tạo -->
          <section class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xs">
            <div class="flex flex-col gap-2 border-b border-slate-100 p-3.5 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h3 class="flex items-center gap-1.5 text-sm font-bold text-slate-800">
                  <i class="fa-solid fa-book-bookmark text-emerald-600"></i>
                  Thông tin đào tạo
                </h3>
                <p class="mt-0.5 text-[11px] text-slate-500">Chỉ tiêu được tổng hợp theo các cấp học đã gán cho cơ sở trong hệ thống.</p>
              </div>
              <span class="w-fit rounded-full bg-emerald-50 px-2.5 py-1 text-[11px] font-semibold text-emerald-700">
                {{ trainingPrograms.length }} ngành / nghề
              </span>
            </div>

            <div v-if="trainingPrograms.length > 0" class="p-3.5 sm:p-4">
              <div class="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-5">
                <div class="rounded-xl border border-blue-100 bg-blue-50 p-3">
                  <div class="text-[11px] font-medium text-slate-500">Tổng chỉ tiêu</div>
                  <div class="mt-1 text-xl font-black text-blue-800">{{ formatQuota(trainingQuotaSummary.total) }}</div>
                  <div class="text-[10px] text-blue-600">SV/năm</div>
                </div>
                <div
                  v-for="level in trainingSummaryCards"
                  :key="level.id"
                  :class="level.cardClass"
                  class="rounded-xl border p-3">
                  <div class="text-[11px] font-medium text-slate-500">{{ level.name }}</div>
                  <div :class="level.valueClass" class="mt-1 text-xl font-black">{{ formatQuota(level.quota) }}</div>
                  <div :class="level.unitClass" class="text-[10px]">SV/năm</div>
                </div>
              </div>

              <div class="overflow-x-auto rounded-xl border border-slate-200">
                <table class="min-w-[720px] w-full border-collapse text-left text-xs">
                  <thead class="border-b border-slate-300 bg-slate-50 text-slate-600">
                    <tr>
                      <th class="min-w-[360px] px-3 py-3 font-semibold">Ngành / nghề đào tạo</th>
                      <th class="min-w-[88px] px-3 py-3 text-right font-semibold">Tổng</th>
                      <th
                        v-for="level in trainingSummaryCards"
                        :key="level.id"
                        class="min-w-[120px] px-3 py-3 text-right font-semibold">
                        {{ level.name }}
                      </th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-200">
                    <tr v-for="program in trainingPrograms" :key="program.key" class="align-top transition-colors hover:bg-slate-50/80">
                      <td class="px-3 py-3">
                        <div class="font-bold leading-snug text-slate-800">{{ program.name }}</div>
                        <div v-if="program.code" class="mt-1 text-[10px] font-mono font-medium text-slate-500">Mã ngành: {{ program.code }}</div>
                      </td>
                      <td class="px-3 py-3 text-right font-bold text-blue-800">{{ formatQuota(program.total) }}</td>
                      <td
                        v-for="level in trainingSummaryCards"
                        :key="`${program.key}-${level.id}`"
                        class="px-3 py-3 text-right text-slate-700">
                        {{ formatQuota(program.quotas[level.id] ?? 0) }}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div v-else class="m-3.5 rounded-lg border border-dashed border-slate-200 bg-slate-50 py-5 text-center text-[11px] italic text-slate-400">
              <span v-if="school.education_level === 'gdtx'">Chương trình đào tạo GDTX & Phổ thông đang được cập nhật.</span>
              <span v-else>Chưa có danh mục ngành đào tạo trong cơ sở dữ liệu.</span>
            </div>
          </section>

          <!-- 4. Cơ sở vật chất & Thư viện hình ảnh -->
          <div class="bg-white rounded-xl p-3.5 border border-slate-200 shadow-xs">
            <span class="font-bold text-slate-800 text-xs flex items-center gap-1.5 mb-2.5">
              <i class="fa-solid fa-shapes text-amber-600"></i>
              <span>Cơ sở vật chất & Quy mô</span>
            </span>

            <!-- Metric Boxes -->
            <div class="grid grid-cols-3 gap-2 mb-3 text-center">
              <div class="p-2 bg-slate-50 rounded-lg border border-slate-100">
                <div class="text-slate-400 text-[10px] font-medium">Khuôn viên</div>
                <div class="text-sm font-black text-slate-800 font-mono mt-0.5">
                  {{ formatArea(school.campus_area_m2 || school.area_m2) }}
                </div>
              </div>
              <div class="p-2 bg-slate-50 rounded-lg border border-slate-100">
                <div class="text-slate-400 text-[10px] font-medium">Phòng học</div>
                <div class="text-sm font-black text-blue-700 font-mono mt-0.5">
                  {{ school.classroom_count || school.class_count || '—' }}
                </div>
              </div>
              <div class="p-2 bg-slate-50 rounded-lg border border-slate-100">
                <div class="text-slate-400 text-[10px] font-medium">Xưởng / Lab</div>
                <div class="text-sm font-black text-emerald-700 font-mono mt-0.5">
                  {{ school.workshops_count || school.lab_count || '0' }}
                </div>
              </div>
            </div>

            <!-- Image Gallery (Click to open Modal Slider) -->
            <div>
              <div class="flex items-center justify-between text-[11px] text-slate-500 font-medium mb-1.5">
                <span>Hình ảnh khuôn viên & xưởng thực hành:</span>
                <span class="text-blue-600 cursor-pointer hover:underline" @click="openGallerySlider(0)">
                  Xem phóng to ({{ displayGallery.length }} ảnh)
                </span>
              </div>

              <div class="grid grid-cols-3 gap-2">
                <div 
                  v-for="(img, i) in displayGallery.slice(0, 3)" 
                  :key="i"
                  @click="openGallerySlider(i)"
                  class="relative aspect-video rounded-lg overflow-hidden border border-slate-200 cursor-pointer group shadow-xs">
                  <img 
                    :src="img" 
                    :alt="`Ảnh cơ sở ${i+1}`"
                    class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                  />
                  <div class="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                    <i class="fa-solid fa-magnifying-glass-plus text-white text-xs opacity-0 group-hover:opacity-100 transition-opacity"></i>
                  </div>
                  <span v-if="i === 2 && displayGallery.length > 3" class="absolute inset-0 bg-slate-900/70 text-white font-bold flex items-center justify-center text-xs">
                    +{{ displayGallery.length - 3 }} ảnh
                  </span>
                </div>
              </div>
            </div>
          </div>

        </div>

        <!-- ============================================================== -->
        <!-- TAB 2: NHÂN LỰC & HỌC VIÊN                                    -->
        <!-- ============================================================== -->
        <div v-if="activeTab === 'personnel'" class="space-y-4 animate-in fade-in duration-200">
          
          <!-- 1. Số liệu sinh viên (tuyển sinh, tốt nghiệp, đang học) -->
          <div class="bg-white rounded-xl p-3.5 border border-slate-200 shadow-xs">
            <span class="font-bold text-slate-800 text-xs flex items-center gap-1.5 mb-2.5">
              <i class="fa-solid fa-chart-pie text-blue-600"></i>
              <span>Số liệu Sinh viên / Học viên</span>
            </span>

            <div class="grid grid-cols-2 gap-2">
              <div class="p-2.5 bg-blue-50/60 rounded-xl border border-blue-100">
                <div class="text-[10px] text-blue-600 font-semibold">Tuyển sinh hàng năm</div>
                <div class="text-base font-black text-blue-800 font-mono mt-0.5">
                  {{ (school.annual_enrollment ?? 0).toLocaleString('vi-VN') }}
                </div>
                <div class="text-[10px] text-slate-400">chỉ tiêu/năm</div>
              </div>

              <div class="p-2.5 bg-indigo-50/60 rounded-xl border border-indigo-100">
                <div class="text-[10px] text-indigo-600 font-semibold">Quy mô đang học</div>
                <div class="text-base font-black text-indigo-800 font-mono mt-0.5">
                  {{ ((school.student_count || school.current_students) ?? 0).toLocaleString('vi-VN') }}
                </div>
                <div class="text-[10px] text-slate-400">học sinh / sinh viên</div>
              </div>

              <div class="p-2.5 bg-emerald-50/60 rounded-xl border border-emerald-100">
                <div class="text-[10px] text-emerald-600 font-semibold">Tốt nghiệp hàng năm</div>
                <div class="text-base font-black text-emerald-800 font-mono mt-0.5">
                  {{ (school.annual_graduates ?? 0).toLocaleString('vi-VN') }}
                </div>
                <div class="text-[10px] text-slate-400">ra trường/năm</div>
              </div>

              <div class="p-2.5 bg-purple-50/60 rounded-xl border border-purple-100">
                <div class="text-[10px] text-purple-600 font-semibold">Tỷ lệ có việc làm</div>
                <div class="text-base font-black text-purple-800 font-mono mt-0.5">
                  {{ school.employment_rate !== null && school.employment_rate !== undefined ? school.employment_rate : '—' }}%
                </div>
                <div class="text-[10px] text-slate-400">trong 6 tháng đầu</div>
              </div>
            </div>
          </div>

          <!-- 2. Số lượng giáo viên & Thiếu / Thừa -->
          <div class="bg-white rounded-xl p-3.5 border border-slate-200 shadow-xs">
            <span class="font-bold text-slate-800 text-xs flex items-center gap-1.5 mb-2.5">
              <i class="fa-solid fa-chalkboard-user text-indigo-600"></i>
              <span>Giáo viên & Cân đối biên chế</span>
            </span>

            <div class="grid grid-cols-2 gap-2 mb-2">
              <div class="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                <div class="text-[10px] text-slate-500 font-medium">Tổng số GV / Giảng viên</div>
                <div class="text-base font-black text-slate-800 font-mono mt-0.5">
                  {{ school.teacher_count ?? 0 }}
                </div>
                <div class="text-[10px] text-slate-400">người hiện có</div>
              </div>

              <div class="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                <div class="text-[10px] text-slate-500 font-medium">Định biên giao</div>
                <div class="text-base font-black text-slate-800 font-mono mt-0.5">
                  {{ school.teacher_quota ?? 0 }}
                </div>
                <div class="text-[10px] text-slate-400">chỉ tiêu phân bổ</div>
              </div>
            </div>

            <!-- Status banner: Thiếu / Thừa -->
            <div 
              v-if="school.teachers_shortage > 0"
              class="p-2.5 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-between text-rose-800">
              <div class="flex items-center gap-2">
                <i class="fa-solid fa-triangle-exclamation text-rose-600"></i>
                <span class="font-semibold text-[11px]">Tình trạng: Còn THIẾU giáo viên</span>
              </div>
              <span class="font-bold text-xs bg-rose-200/80 px-2 py-0.5 rounded text-rose-900">
                -{{ school.teachers_shortage }} GV
              </span>
            </div>
            <div 
              v-else-if="school.teachers_surplus > 0"
              class="p-2.5 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-between text-amber-800">
              <div class="flex items-center gap-2">
                <i class="fa-solid fa-circle-info text-amber-600"></i>
                <span class="font-semibold text-[11px]">Tình trạng: Dôi dư giáo viên</span>
              </div>
              <span class="font-bold text-xs bg-amber-200/80 px-2 py-0.5 rounded text-amber-900">
                +{{ school.teachers_surplus }} GV
              </span>
            </div>
            <div 
              v-else-if="school.teacher_quota > 0"
              class="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-between text-emerald-800">
              <div class="flex items-center gap-2">
                <i class="fa-solid fa-circle-check text-emerald-600"></i>
                <span class="font-semibold text-[11px]">Tình trạng: Cân đối đủ định biên</span>
              </div>
              <span class="font-bold text-xs bg-emerald-200/80 px-2 py-0.5 rounded text-emerald-900">
                Đủ chỉ tiêu
              </span>
            </div>
            <div 
              v-else
              class="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between text-slate-500">
              <div class="flex items-center gap-2">
                <i class="fa-solid fa-circle-info text-slate-400"></i>
                <span class="font-semibold text-[11px]">Định biên: Đang cập nhật</span>
              </div>
              <span class="text-[11px] text-slate-400 italic">
                Chưa có dữ liệu
              </span>
            </div>
          </div>

          <!-- 3. Phân loại giảng viên theo Ngạch / Hạng -->
          <div class="bg-white rounded-xl p-3.5 border border-slate-200 shadow-xs">
            <span class="font-bold text-slate-800 text-xs flex items-center gap-1.5 mb-2.5">
              <i class="fa-solid fa-ranking-star text-purple-600"></i>
              <span>Phân loại Giảng viên theo Ngạch</span>
            </span>

            <div class="space-y-2">
              <div class="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                <div class="flex items-center gap-2">
                  <span class="w-6 h-6 rounded bg-purple-100 text-purple-800 font-bold flex items-center justify-center text-[10px]">I</span>
                  <div>
                    <div class="font-bold text-slate-800 text-[11px]">Loại 1 (Giảng viên cao cấp)</div>
                    <div class="text-[10px] text-slate-400">Ngạch viên chức Hạng I</div>
                  </div>
                </div>
                <div class="font-black text-purple-700 text-sm font-mono">
                  {{ school.faculty_rank_1 ?? 0 }}
                </div>
              </div>

              <div class="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                <div class="flex items-center gap-2">
                  <span class="w-6 h-6 rounded bg-blue-100 text-blue-800 font-bold flex items-center justify-center text-[10px]">II</span>
                  <div>
                    <div class="font-bold text-slate-800 text-[11px]">Loại 2 (Giảng viên chính)</div>
                    <div class="text-[10px] text-slate-400">Ngạch viên chức Hạng II</div>
                  </div>
                </div>
                <div class="font-black text-blue-700 text-sm font-mono">
                  {{ school.faculty_rank_2 ?? 0 }}
                </div>
              </div>

              <div class="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                <div class="flex items-center gap-2">
                  <span class="w-6 h-6 rounded bg-slate-200 text-slate-700 font-bold flex items-center justify-center text-[10px]">III</span>
                  <div>
                    <div class="font-bold text-slate-800 text-[11px]">Giảng viên Hạng III</div>
                    <div class="text-[10px] text-slate-400">Giảng viên tiêu chuẩn</div>
                  </div>
                </div>
                <div class="font-black text-slate-700 text-sm font-mono">
                  {{ school.faculty_rank_3 ?? 0 }}
                </div>
              </div>
            </div>
          </div>

          <!-- 4. Học hàm / Học vị -->
          <div class="bg-white rounded-xl p-3.5 border border-slate-200 shadow-xs">
            <span class="font-bold text-slate-800 text-xs flex items-center gap-1.5 mb-2.5">
              <i class="fa-solid fa-award text-amber-600"></i>
              <span>Học hàm / Học vị sau Đại học</span>
            </span>

            <div class="grid grid-cols-3 gap-2 text-center">
              <div class="p-2.5 bg-amber-50/60 rounded-xl border border-amber-100">
                <div class="text-[10px] text-amber-700 font-semibold">Tiến sĩ (TS)</div>
                <div class="text-base font-black text-amber-900 font-mono mt-0.5">
                  {{ school.faculty_doctors ?? 0 }}
                </div>
                <div class="text-[10px] text-amber-600">cán bộ</div>
              </div>

              <div class="p-2.5 bg-blue-50/60 rounded-xl border border-blue-100">
                <div class="text-[10px] text-blue-700 font-semibold">Thạc sĩ (ThS)</div>
                <div class="text-base font-black text-blue-900 font-mono mt-0.5">
                  {{ school.faculty_masters ?? 0 }}
                </div>
                <div class="text-[10px] text-blue-600">cán bộ</div>
              </div>

              <div class="p-2.5 bg-rose-50/60 rounded-xl border border-rose-100">
                <div class="text-[10px] text-rose-700 font-semibold">GS / PGS</div>
                <div class="text-base font-black text-rose-900 font-mono mt-0.5">
                  {{ school.faculty_professors ?? 0 }}
                </div>
                <div class="text-[10px] text-rose-600">chuyên gia</div>
              </div>
            </div>
          </div>

        </div>

        <!-- ============================================================== -->
        <!-- TAB 3: DOANH NGHIỆP                                           -->
        <!-- ============================================================== -->
        <div v-if="activeTab === 'enterprises'" class="space-y-4 animate-in fade-in duration-200">
          
          <!-- Slider 4-5 Doanh nghiệp tiêu biểu -->
          <div class="bg-white rounded-xl p-3.5 border border-slate-200 shadow-xs">
            <div class="flex items-center justify-between mb-3">
              <span class="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <i class="fa-solid fa-briefcase text-blue-600"></i>
                <span>Doanh nghiệp liên kết tiêu biểu</span>
              </span>
              <div class="flex items-center gap-1">
                <button 
                  @click="prevEnterpriseSlide" 
                  class="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer transition-colors"
                  title="Trước">
                  <i class="fa-solid fa-chevron-left text-[10px]"></i>
                </button>
                <span class="text-[10px] font-mono text-slate-400 px-1">
                  {{ currentEnterpriseIndex + 1 }}/{{ featuredEnterprises.length || 1 }}
                </span>
                <button 
                  @click="nextEnterpriseSlide" 
                  class="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer transition-colors"
                  title="Tiếp theo">
                  <i class="fa-solid fa-chevron-right text-[10px]"></i>
                </button>
              </div>
            </div>

            <!-- Single Slide Display -->
            <div v-if="featuredEnterprises.length > 0" class="overflow-hidden">
              <div class="p-3 bg-gradient-to-br from-slate-50 to-blue-50/40 rounded-xl border border-blue-100 flex items-center gap-3">
                <div class="w-12 h-12 rounded-xl bg-white border border-slate-200 p-1 flex items-center justify-center flex-shrink-0 shadow-xs overflow-hidden">
                  <img 
                    v-if="featuredEnterprises[currentEnterpriseIndex]?.logo"
                    :src="featuredEnterprises[currentEnterpriseIndex].logo"
                    alt="Logo doanh nghiệp"
                    class="w-full h-full object-contain" 
                  />
                  <i v-else class="fa-solid fa-building text-blue-600 text-lg"></i>
                </div>
                <div class="min-w-0 flex-1">
                  <h4 class="font-bold text-slate-800 text-[13px] leading-snug">
                    {{ featuredEnterprises[currentEnterpriseIndex]?.name }}
                  </h4>
                </div>
              </div>
            </div>
            <div v-else class="text-[11px] text-slate-400 italic text-center py-4">
              Chưa có dữ liệu doanh nghiệp liên kết
            </div>

            <!-- Dots indicator -->
            <div v-if="featuredEnterprises.length > 1" class="flex items-center justify-center gap-1.5 mt-2.5">
              <span 
                v-for="(_, i) in featuredEnterprises" 
                :key="i"
                @click="currentEnterpriseIndex = i"
                :class="i === currentEnterpriseIndex ? 'w-4 bg-blue-600' : 'w-1.5 bg-slate-300 hover:bg-slate-400'"
                class="h-1.5 rounded-full transition-all cursor-pointer">
              </span>
            </div>

            <!-- Button: Open full modal -->
            <button 
              v-if="allEnterprises.length > 0"
              @click="isEnterprisesModalOpen = true"
              class="w-full mt-3 py-2 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs">
              <i class="fa-solid fa-list-check"></i>
              <span>Xem toàn bộ danh sách doanh nghiệp ({{ allEnterprises.length }})</span>
            </button>
          </div>

        </div>

      </div>

      <!-- Bottom Quick Action Bar -->
      <div class="p-3 border-t border-slate-200 bg-white flex items-center gap-2 flex-shrink-0">
        <a 
          :href="`https://www.google.com/maps/dir/?api=1&destination=${school.lat},${school.lng}`" 
          target="_blank"
          class="flex-1 py-2 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer text-decoration-none">
          <i class="fa-solid fa-diamond-turn-right text-xs"></i>
          <span>Chỉ đường</span>
        </a>

        <button 
          @click="$emit('buffer-analyze', school)"
          class="flex-1 py-2 rounded-lg bg-purple-50 text-purple-700 hover:bg-purple-100 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer">
          <i class="fa-solid fa-bullseye text-xs"></i>
          <span>Bán kính 3km</span>
        </button>

        <button 
          @click="$emit('close')"
          class="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-semibold transition-colors cursor-pointer">
          Đóng
        </button>
      </div>

    </div>

    <!-- ============================================================== -->
    <!-- MODAL SLIDER: PHOTO LIGHTBOX CAROUSEL                         -->
    <!-- ============================================================== -->
    <div 
      v-if="isGalleryModalOpen" 
      class="fixed inset-0 z-[2500] bg-black/90 backdrop-blur-sm flex flex-col items-center justify-center p-4 animate-in fade-in select-none">
      
      <!-- Top controls -->
      <div class="absolute top-4 left-4 right-4 flex items-center justify-between text-white z-10">
        <div class="flex items-center gap-2 text-xs">
          <span class="font-bold text-sm">{{ school?.name }}</span>
          <span class="text-white/40">|</span>
          <span class="bg-white/20 px-2.5 py-0.5 rounded-full text-xs font-mono">
            {{ currentGalleryIndex + 1 }} / {{ displayGallery.length }}
          </span>
        </div>
        <button 
          @click="isGalleryModalOpen = false"
          class="w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center cursor-pointer transition-colors text-lg">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <!-- Main Slider Image -->
      <div class="relative max-w-4xl max-h-[75vh] w-full flex items-center justify-center">
        <button 
          @click="prevGalleryImage"
          class="absolute left-2 sm:-left-12 w-10 h-10 rounded-full bg-white/20 hover:bg-white/40 text-white flex items-center justify-center cursor-pointer transition-all z-10">
          <i class="fa-solid fa-chevron-left text-base"></i>
        </button>

        <img 
          :src="displayGallery[currentGalleryIndex]" 
          :alt="`Ảnh cơ sở ${currentGalleryIndex + 1}`"
          class="max-w-full max-h-[75vh] object-contain rounded-xl shadow-2xl animate-in zoom-in-95 duration-200" 
        />

        <button 
          @click="nextGalleryImage"
          class="absolute right-2 sm:-right-12 w-10 h-10 rounded-full bg-white/20 hover:bg-white/40 text-white flex items-center justify-center cursor-pointer transition-all z-10">
          <i class="fa-solid fa-chevron-right text-base"></i>
        </button>
      </div>

      <!-- Thumbnail Strip at bottom -->
      <div class="flex items-center gap-2 mt-4 overflow-x-auto max-w-xl py-1 px-2">
        <div 
          v-for="(img, idx) in displayGallery" 
          :key="idx"
          @click="currentGalleryIndex = idx"
          :class="idx === currentGalleryIndex ? 'ring-2 ring-blue-500 scale-105' : 'opacity-50 hover:opacity-100'"
          class="w-14 h-10 rounded-lg overflow-hidden flex-shrink-0 cursor-pointer transition-all border border-white/20">
          <img :src="img" class="w-full h-full object-cover" />
        </div>
      </div>
    </div>

    <!-- ============================================================== -->
    <!-- MODAL POPUP: ALL TRAINING MAJORS                              -->
    <!-- ============================================================== -->
    <div
      v-if="isMajorsModalOpen"
      class="fixed inset-0 z-[2500] flex items-center justify-center bg-slate-900/60 p-3 backdrop-blur-xs animate-in fade-in select-none sm:p-4">

      <div class="flex max-h-[85vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl animate-in zoom-in-95 duration-150">
        <div class="flex flex-shrink-0 items-center justify-between bg-gradient-to-r from-emerald-700 to-teal-700 p-4 text-white">
          <div class="flex min-w-0 items-center gap-2">
            <i class="fa-solid fa-book-bookmark text-base text-emerald-100"></i>
            <div class="min-w-0">
              <h3 class="text-sm font-bold leading-tight">Ngành / nghề đào tạo</h3>
              <p class="truncate text-[11px] text-emerald-100">{{ school?.name }} · {{ displayMajors.length }} ngành, nghề</p>
            </div>
          </div>
          <button
            @click="isMajorsModalOpen = false"
            class="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full bg-white/20 text-white transition-colors hover:bg-white/30">
            <i class="fa-solid fa-xmark text-xs"></i>
          </button>
        </div>

        <div class="border-b border-slate-100 bg-slate-50 p-3">
          <label class="relative block">
            <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400"></i>
            <input
              v-model="majorSearchQuery"
              type="search"
              placeholder="Tìm theo tên hoặc mã ngành..."
              class="w-full rounded-lg border border-slate-200 bg-white py-2 pl-8 pr-3 text-xs text-slate-700 outline-none transition-colors placeholder:text-slate-400 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
            />
          </label>
        </div>

        <div class="hidden grid-cols-[minmax(0,1fr)_130px_110px] gap-3 border-b border-slate-200 bg-slate-50 px-4 py-2 text-[10px] font-bold uppercase tracking-wide text-slate-500 sm:grid">
          <span>Ngành / nghề</span>
          <span>Trình độ</span>
          <span class="text-right">Chỉ tiêu</span>
        </div>

        <div class="flex-1 overflow-y-auto">
          <div
            v-for="(major, index) in filteredMajors"
            :key="`${major.id || major.name}-${index}`"
            class="grid gap-2 border-b border-slate-100 px-4 py-3 last:border-b-0 sm:grid-cols-[minmax(0,1fr)_130px_110px] sm:items-center sm:gap-3">
            <div class="min-w-0">
              <div class="text-xs font-bold leading-snug text-slate-800">{{ major.name }}</div>
              <div v-if="getMajorCode(major)" class="mt-1 inline-flex rounded bg-slate-100 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-slate-600">
                Mã: {{ getMajorCode(major) }}
              </div>
            </div>
            <div>
              <span class="inline-flex rounded bg-blue-50 px-1.5 py-0.5 text-[10px] font-semibold text-blue-700">
                {{ formatDegreeLevel(major.degree_level) }}
              </span>
            </div>
            <div class="text-left text-[11px] text-slate-600 sm:text-right">
              <template v-if="major.annual_quota">
                <strong class="text-blue-700">{{ major.annual_quota }}</strong> SV/năm
              </template>
              <span v-else>—</span>
            </div>
          </div>

          <div v-if="filteredMajors.length === 0" class="px-4 py-10 text-center text-xs italic text-slate-400">
            Không tìm thấy ngành / nghề phù hợp.
          </div>
        </div>

        <div class="flex flex-shrink-0 justify-end border-t border-slate-200 bg-slate-50 p-3">
          <button
            @click="isMajorsModalOpen = false"
            class="rounded-lg bg-slate-200 px-4 py-1.5 text-xs font-semibold text-slate-700 transition-colors hover:bg-slate-300">
            Đóng
          </button>
        </div>
      </div>
    </div>

    <!-- ============================================================== -->
    <!-- MODAL POPUP: ALL PARTNER ENTERPRISES                          -->
    <!-- ============================================================== -->
    <div 
      v-if="isEnterprisesModalOpen"
      class="fixed inset-0 z-[2500] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in select-none">
      
      <div class="bg-white rounded-2xl max-w-xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
        
        <!-- Header -->
        <div class="p-4 bg-gradient-to-r from-blue-800 to-indigo-800 text-white flex items-center justify-between flex-shrink-0">
          <div class="flex items-center gap-2">
            <i class="fa-solid fa-handshake text-base text-blue-200"></i>
            <div>
              <h3 class="font-bold text-sm leading-tight">Danh sách Doanh nghiệp liên kết</h3>
              <p class="text-[11px] text-blue-100">{{ school?.name }}</p>
            </div>
          </div>
          <button 
            @click="isEnterprisesModalOpen = false"
            class="w-7 h-7 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center cursor-pointer transition-colors">
            <i class="fa-solid fa-xmark text-xs"></i>
          </button>
        </div>

        <!-- Search bar -->
        <div class="p-3 border-b border-slate-100 bg-slate-50 flex items-center gap-2">
          <i class="fa-solid fa-magnifying-glass text-slate-400 text-xs ml-1"></i>
          <input 
            v-model="enterpriseSearchQuery"
            type="text" 
            placeholder="Tìm theo tên doanh nghiệp..."
            class="bg-transparent border-none text-xs w-full focus:outline-none text-slate-700 placeholder:text-slate-400"
          />
        </div>

        <!-- List container -->
        <div class="flex-1 overflow-y-auto p-4 space-y-2.5">
          <div 
            v-for="(ent, i) in filteredAllEnterprises" 
            :key="i"
            class="p-3 rounded-xl bg-slate-50 border border-slate-200 hover:border-blue-300 transition-colors flex items-center gap-3">
            <div class="w-10 h-10 rounded-lg bg-white border border-slate-200 p-1 flex items-center justify-center flex-shrink-0 overflow-hidden">
              <img 
                v-if="ent.logo" 
                :src="ent.logo" 
                alt="Logo" 
                class="w-full h-full object-contain" 
              />
              <i v-else class="fa-solid fa-building text-blue-600 text-base"></i>
            </div>
            <div class="flex-1 min-w-0">
              <h4 class="font-bold text-slate-800 text-xs truncate">{{ ent.name }}</h4>
            </div>
          </div>

          <div v-if="filteredAllEnterprises.length === 0" class="text-center py-6 text-slate-400 text-xs italic">
            Không tìm thấy doanh nghiệp phù hợp với từ khóa
          </div>
        </div>

        <!-- Footer -->
        <div class="p-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button 
            @click="isEnterprisesModalOpen = false"
            class="px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold transition-colors cursor-pointer">
            Đóng
          </button>
        </div>
      </div>
    </div>

  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { LEVEL_MAP } from '../../services/schoolService'

const props = defineProps({
  school: {
    type: Object,
    default: null
  }
})

const emit = defineEmits(['close', 'buffer-analyze', 'view-related-campus', 'fit-campuses'])

// Dynamic level icon matching map pin
const levelIcon = computed(() => {
  return LEVEL_MAP[props.school?.education_level]?.icon || 'fa-solid fa-graduation-cap'
})

// Active tab in drawer
const activeTab = ref('general') // 'general' | 'personnel' | 'enterprises'

// Enterprise Slider & Modal
const currentEnterpriseIndex = ref(0)
const isEnterprisesModalOpen = ref(false)
const enterpriseSearchQuery = ref('')

// Training-major detail modal
const isMajorsModalOpen = ref(false)
const majorSearchQuery = ref('')

// Image Gallery Modal Lightbox
const isGalleryModalOpen = ref(false)
const currentGalleryIndex = ref(0)

// Helper: level label
const levelLabel = computed(() => {
  return props.school?.education_level_name || props.school?.education_level || 'Cơ sở giáo dục'
})

const relatedCampuses = computed(() => {
  const items = props.school?.campus_group?.items
  return Array.isArray(items) ? items : []
})

const campusSearchQuery = ref('')

const mainCampusesCount = computed(() => {
  return relatedCampuses.value.filter(c => c.campus_type === 'MAIN').length
})

const subCampusesCount = computed(() => {
  return relatedCampuses.value.filter(c => c.campus_type !== 'MAIN').length
})

function getCampusDisplayName(campus) {
  if (campus.campus_name && campus.campus_name.trim()) {
    return campus.campus_name.trim()
  }

  const isMain = campus.campus_type === 'MAIN'
  const note = campus.campus_note?.trim() || ''

  if (isMain) {
    if (!note || /^(cơ sở chính|trụ sở chính)$/i.test(note)) {
      return 'Trụ sở chính'
    }
    if (/^(cơ sở|khu|địa điểm)\s*\d+/i.test(note)) {
      return `${note} (Trụ sở chính)`
    }
    return `Trụ sở chính – ${note}`
  }

  if (note) {
    return note
  }

  if (campus.name) {
    const parts = campus.name.split(/[–—-]/)
    if (parts.length > 1) {
      const lastPart = parts[parts.length - 1].trim()
      if (/cơ sở|khu|địa điểm|phân hiệu/i.test(lastPart)) {
        return lastPart
      }
    }
  }

  return campus.name || 'Cơ sở đào tạo'
}

const filteredCampuses = computed(() => {
  const list = relatedCampuses.value
  const q = campusSearchQuery.value.trim().toLowerCase()
  if (!q) return list
  return list.filter(c => {
    const name = (getCampusDisplayName(c) || '').toLowerCase()
    const ward = (c.ward || '').toLowerCase()
    const addr = (c.address || '').toLowerCase()
    return name.includes(q) || ward.includes(q) || addr.includes(q)
  })
})

// Safe parser for JSON or array fields from Database
function parseArrayField(val) {
  if (!val) return []
  if (Array.isArray(val)) return val
  if (typeof val === 'string') {
    try {
      const parsed = JSON.parse(val)
      return Array.isArray(parsed) ? parsed : []
    } catch (e) {
      return []
    }
  }
  return []
}

// Leaders list directly from DB
const displayLeaders = computed(() => {
  const leaders = parseArrayField(props.school?.leaders)
  if (leaders.length > 0) {
    return leaders
  }
  if (props.school?.principal) {
    return [
      { name: props.school.principal, position: 'Hiệu trưởng' }
    ]
  }
  return []
})

// Majors list directly from DB
const displayMajors = computed(() => {
  return parseArrayField(props.school?.training_majors)
})

const TRAINING_LEVEL_ORDER = ['dai_hoc', 'cao_dang', 'trung_cap', 'so_cap', 'gdtx']

const EDUCATION_LEVEL_CARD_STYLES = {
  gdtx: {
    cardClass: 'border-violet-100 bg-violet-50',
    valueClass: 'text-violet-800',
    unitClass: 'text-violet-600',
  },
  trung_cap: {
    cardClass: 'border-amber-100 bg-amber-50',
    valueClass: 'text-amber-800',
    unitClass: 'text-amber-600',
  },
  cao_dang: {
    cardClass: 'border-emerald-100 bg-emerald-50',
    valueClass: 'text-emerald-800',
    unitClass: 'text-emerald-600',
  },
  dai_hoc: {
    cardClass: 'border-indigo-100 bg-indigo-50',
    valueClass: 'text-indigo-800',
    unitClass: 'text-indigo-600',
  },
}

const DEFAULT_EDUCATION_LEVEL_CARD_STYLE = {
  cardClass: 'border-slate-200 bg-slate-50',
  valueClass: 'text-slate-800',
  unitClass: 'text-slate-600',
}

const trainingPrograms = computed(() => {
  const grouped = new Map()

  displayMajors.value.forEach((major, index) => {
    const name = String(major?.name || 'Chưa cập nhật tên ngành').trim()
    const code = getMajorCode(major)
    const key = `${name.toLocaleLowerCase('vi-VN')}|${code}`
    const degreeLevel = normalizeTrainingLevel(major?.degree_level)
    const quota = Number(major?.annual_quota ?? 0)
    const safeQuota = Number.isFinite(quota) && quota >= 0 ? quota : 0

    if (!grouped.has(key)) {
      grouped.set(key, {
        key: `${key}|${index}`,
        name,
        code,
        levels: new Set(),
        total: 0,
        quotas: {},
      })
    }

    const program = grouped.get(key)
    program.levels.add(degreeLevel)
    program.total += safeQuota
    program.quotas[degreeLevel] = (program.quotas[degreeLevel] ?? 0) + safeQuota
  })

  return Array.from(grouped.values())
    .map(program => ({
      ...program,
      levels: Array.from(program.levels).sort((a, b) => {
        const left = TRAINING_LEVEL_ORDER.indexOf(a)
        const right = TRAINING_LEVEL_ORDER.indexOf(b)
        return (left === -1 ? 99 : left) - (right === -1 ? 99 : right)
      }),
    }))
    .sort((a, b) => a.name.localeCompare(b.name, 'vi'))
})

const trainingQuotaSummary = computed(() => {
  return {
    total: trainingPrograms.value.reduce((total, program) => total + program.total, 0),
  }
})

// Use the complete DB catalog for the cards and table columns. A level must
// remain visible even when this school currently has no programme for it.
const schoolEducationLevels = computed(() => {
  const catalog = Array.isArray(props.school?.education_levels_catalog)
    ? props.school.education_levels_catalog
    : []
  const assignedLevels = Array.isArray(props.school?.education_levels)
    ? props.school.education_levels
    : []

  const fallbackIds = Array.isArray(props.school?.education_level_ids)
    ? props.school.education_level_ids
    : [props.school?.education_level || props.school?.education_level_id]

  const source = catalog.length > 0
    ? catalog
    : assignedLevels.length > 0
      ? assignedLevels
    : fallbackIds.map(id => ({ id, name: getEducationLevelLabel(id) }))

  const unique = new Map()
  source.forEach((level, index) => {
    const id = normalizeEducationLevelId(level?.id)
    if (!id || unique.has(id)) return

    unique.set(id, {
      id,
      name: String(level?.name || getEducationLevelLabel(id)).trim() || getEducationLevelLabel(id),
      displayOrder: Number(level?.display_order ?? index),
    })
  })

  return Array.from(unique.values())
    .sort((left, right) => left.displayOrder - right.displayOrder || left.name.localeCompare(right.name, 'vi'))
})

const trainingSummaryCards = computed(() => {
  const levels = schoolEducationLevels.value
  const quotasByLevel = {}
  const total = trainingQuotaSummary.value.total

  displayMajors.value.forEach(major => {
    const levelId = normalizeEducationLevelId(major?.degree_level)
    const quota = Number(major?.annual_quota ?? 0)
    if (!levelId || !Number.isFinite(quota) || quota < 0) return
    quotasByLevel[levelId] = (quotasByLevel[levelId] ?? 0) + quota
  })

  const hasMappedQuota = levels.some(level => Object.prototype.hasOwnProperty.call(quotasByLevel, level.id))

  return levels.map(level => {
    // Historical records for a single-level school sometimes store the
    // programme's detailed degree (e.g. sơ cấp) instead of its school level
    // (e.g. GDTX). In that safe case, the whole quota belongs to its only
    // configured level. Multiple-level schools are never guessed.
    const quota = hasMappedQuota || levels.length !== 1
      ? (quotasByLevel[level.id] ?? 0)
      : total
    const style = EDUCATION_LEVEL_CARD_STYLES[level.id] || DEFAULT_EDUCATION_LEVEL_CARD_STYLE

    return {
      ...level,
      quota,
      ...style,
    }
  })
})

const previewMajors = computed(() => displayMajors.value.slice(0, 4))

const filteredMajors = computed(() => {
  const query = majorSearchQuery.value.trim().toLocaleLowerCase('vi-VN')
  if (!query) return displayMajors.value

  return displayMajors.value.filter(major => [major?.name, getMajorCode(major)]
    .filter(Boolean)
    .some(value => String(value).toLocaleLowerCase('vi-VN').includes(query)))
})

function getMajorCode(major) {
  const code = major?.code ?? major?.major_code
  return code ? String(code).trim() : ''
}

function normalizeTrainingLevel(level) {
  const normalized = normalizeEducationLevelId(level)
  return TRAINING_LEVEL_ORDER.includes(normalized) ? normalized : normalized || 'khac'
}

function normalizeEducationLevelId(level) {
  return String(level || '').trim().toLocaleLowerCase('vi-VN').replace(/-/g, '_')
}

function getEducationLevelLabel(level) {
  const labels = {
    gdtx: 'GDTX - GDNN',
    trung_cap: 'Trung cấp',
    cao_dang: 'Cao đẳng',
    dai_hoc: 'Đại học',
  }

  return labels[normalizeEducationLevelId(level)] || 'Cấp học'
}

function formatQuota(value) {
  const quota = Number(value)
  return Number.isFinite(quota) ? quota.toLocaleString('vi-VN') : '—'
}

function formatDegreeLevel(level) {
  const configuredLevel = schoolEducationLevels.value.find(item => item.id === normalizeEducationLevelId(level))
  if (configuredLevel) return configuredLevel.name

  const labels = {
    dai_hoc: 'Đại học',
    cao_dang: 'Cao đẳng',
    trung_cap: 'Trung cấp',
    so_cap: 'Sơ cấp',
    gdtx: 'GDTX - GDNN',
  }

  return labels[normalizeTrainingLevel(level)] || 'Chưa cập nhật'
}

function formatArea(area) {
  if (!area) return '—'
  if (area >= 10000) {
    return `${(area / 10000).toFixed(1)} ha`
  }
  return `${area.toLocaleString('vi-VN')} m²`
}

// Gallery list directly from DB
const displayGallery = computed(() => {
  const gallery = parseArrayField(props.school?.gallery)
  if (gallery.length > 0) {
    return gallery.map(img => {
      if (typeof img === 'string' && (img.startsWith('http') || img.startsWith('/'))) return img
      const storageBase = window.location.origin.includes('localhost:517') ? 'http://localhost:8000' : ''
      return `${storageBase}/storage/${img}`
    })
  }
  if (props.school?.image_url) {
    return [props.school.image_url]
  }
  return [
    'https://images.unsplash.com/photo-1562774053-701939374585?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80'
  ]
})

function openGallerySlider(index = 0) {
  currentGalleryIndex.value = index
  isGalleryModalOpen.value = true
}

function nextGalleryImage() {
  currentGalleryIndex.value = (currentGalleryIndex.value + 1) % displayGallery.value.length
}

function prevGalleryImage() {
  currentGalleryIndex.value = (currentGalleryIndex.value - 1 + displayGallery.value.length) % displayGallery.value.length
}

// Enterprises directly from DB
const allEnterprises = computed(() => {
  return parseArrayField(props.school?.partner_enterprises)
})

const featuredEnterprises = computed(() => {
  const featured = allEnterprises.value.filter(e => e.is_featured)
  return featured.length > 0 ? featured : allEnterprises.value.slice(0, 5)
})

const filteredAllEnterprises = computed(() => {
  if (!enterpriseSearchQuery.value) return allEnterprises.value
  const q = enterpriseSearchQuery.value.toLowerCase().trim()
  return allEnterprises.value.filter(e => 
    e.name && e.name.toLowerCase().includes(q)
  )
})

function nextEnterpriseSlide() {
  if (featuredEnterprises.value.length === 0) return
  currentEnterpriseIndex.value = (currentEnterpriseIndex.value + 1) % featuredEnterprises.value.length
}

function prevEnterpriseSlide() {
  if (featuredEnterprises.value.length === 0) return
  currentEnterpriseIndex.value = (currentEnterpriseIndex.value - 1 + featuredEnterprises.value.length) % featuredEnterprises.value.length
}

// Keyboard navigation (Esc to close modals)
function handleKeydown(e) {
  if (e.key === 'Escape') {
    if (isGalleryModalOpen.value) {
      isGalleryModalOpen.value = false
    } else if (isMajorsModalOpen.value) {
      isMajorsModalOpen.value = false
    } else if (isEnterprisesModalOpen.value) {
      isEnterprisesModalOpen.value = false
    } else if (props.school) {
      emit('close')
    }
  } else if (e.key === 'ArrowRight' && isGalleryModalOpen.value) {
    nextGalleryImage()
  } else if (e.key === 'ArrowLeft' && isGalleryModalOpen.value) {
    prevGalleryImage()
  }
}

onMounted(() => {
  window.addEventListener('keydown', handleKeydown)
})

onUnmounted(() => {
  window.removeEventListener('keydown', handleKeydown)
})
</script>
