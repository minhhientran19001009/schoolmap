<?php

namespace App\Filament\Resources\Schools\Schemas;

use App\Models\School;
use App\Models\Ward;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Schemas\Components\View;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;

class SchoolForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Tabs::make('SchoolTabs')
                    ->columnSpanFull()
                    ->tabs([
                        // ==============================================================
                        // TAB 1: THÔNG TIN CHUNG (Bao gồm Cơ sở vật chất)
                        // ==============================================================
                        Tab::make('Thông tin chung')
                            ->icon(Heroicon::OutlinedBuildingLibrary)
                            ->schema([
                                Grid::make(3)->schema([
                                    TextInput::make('name')
                                        ->label('Tên Cơ sở Giáo dục')
                                        ->placeholder('VD: Trường Cao đẳng Cơ giới Ninh Bình')
                                        ->required()
                                        ->columnSpan(['default' => 3, 'lg' => 1]),

                                    TextInput::make('phone')
                                        ->label('Số điện thoại liên hệ')
                                        ->tel()
                                        ->placeholder('VD: 0229 387 1042')
                                        ->columnSpan(['default' => 3, 'lg' => 1]),

                                    TextInput::make('website')
                                        ->label('Trang web / Cổng thông tin điện tử')
                                        ->url()
                                        ->placeholder('VD: https://cdyteninhbinh.edu.vn')
                                        ->prefixIcon('heroicon-m-globe-alt')
                                        ->columnSpan(['default' => 3, 'lg' => 1]),
                                ]),

                                Grid::make(2)->schema([
                                    Select::make('educationLevels')
                                        ->label('Cấp học / Danh mục đào tạo')
                                        ->relationship('educationLevels', 'name')
                                        ->multiple()
                                        ->preload()
                                        ->placeholder('Chọn một hoặc nhiều cấp học / cơ sở')
                                        ->required(),

                                    Select::make('ward')
                                        ->label('Thuộc Phường / Xã')
                                        ->options(function () {
                                            return Ward::orderBy('full_name')->pluck('full_name', 'full_name')->toArray();
                                        })
                                        ->searchable()
                                        ->placeholder('Chọn Phường / Xã')
                                        ->extraAttributes(['id' => 'school-ward-select']),
                                ]),

                                Section::make('Quan hệ cơ sở / phân hiệu')
                                    ->description('Mỗi cơ sở có địa chỉ và tọa độ riêng. Chọn cơ sở chính để nhóm các địa điểm cùng một đơn vị khi hiển thị trên bản đồ.')
                                    ->schema([
                                        Grid::make(3)->schema([
                                            Select::make('campus_type')
                                                ->label('Loại cơ sở')
                                                ->options(School::campusTypeLabels())
                                                ->default('MAIN')
                                                ->required()
                                                ->live()
                                                ->afterStateUpdated(function (Set $set, ?string $state): void {
                                                    if ($state === 'MAIN') {
                                                        $set('parent_school_id', null);
                                                    }
                                                })
                                                ->native(false),

                                            Select::make('parent_school_id')
                                                ->label('Cơ sở chính')
                                                ->options(fn () => School::query()
                                                    ->where('campus_type', 'MAIN')
                                                    ->orderBy('name')
                                                    ->pluck('name', 'id')
                                                ->all())
                                                ->searchable()
                                                ->preload()
                                                ->disabled(fn (Get $get): bool => $get('campus_type') === 'MAIN')
                                                ->dehydrated()
                                                ->required(fn (Get $get): bool => $get('campus_type') !== 'MAIN')
                                                ->helperText(fn (Get $get): string => $get('campus_type') === 'MAIN'
                                                    ? 'Không áp dụng cho cơ sở chính.'
                                                    : 'Bắt buộc chọn cơ sở chính cho cơ sở trực thuộc hoặc phân hiệu.'),

                                            TextInput::make('campus_name')
                                                ->label('Tên cơ sở / phân hiệu')
                                                ->maxLength(150)
                                                ->placeholder('VD: Cơ sở Tam Điệp'),

                                        ]),
                                    ]),

                                // Bộ chọn vị trí trên bản đồ Leaflet
                                View::make('filament.forms.components.location-picker')
                                    ->columnSpanFull()
                                    ->viewData(fn ($record = null) => [
                                        'initialLat' => $record?->lat ?? 20.2506,
                                        'initialLng' => $record?->lng ?? 105.9745,
                                    ]),

                                Hidden::make('lat')
                                    ->default(20.2506)
                                    ->extraAttributes(['id' => 'school-lat-input']),

                                Hidden::make('lng')
                                    ->default(105.9745)
                                    ->extraAttributes(['id' => 'school-lng-input']),

                                Hidden::make('address')
                                    ->extraAttributes(['id' => 'school-address-input']),

                                // Cơ sở vật chất & Thư viện Hình ảnh nằm trong Thông tin chung
                                Section::make('Cơ sở vật chất & Thư viện Hình ảnh')
                                    ->description('Quy mô phòng học, xưởng thực hành và hình ảnh khuôn viên trường học')
                                    ->schema([
                                        Grid::make(3)->schema([
                                            TextInput::make('campus_area_m2')
                                                ->label('Diện tích khuôn viên (m²)')
                                                ->numeric()
                                                ->placeholder('VD: 25000'),

                                            TextInput::make('classroom_count')
                                                ->label('Số phòng học / Giảng đường')
                                                ->numeric()
                                                ->default(0),

                                            TextInput::make('workshops_count')
                                                ->label('Số xưởng thực hành / Lab')
                                                ->numeric()
                                                ->default(0),
                                        ]),

                                        FileUpload::make('gallery')
                                            ->label('Thư viện ảnh trường học (Khuôn viên, giảng đường, xưởng thực hành, KTX...)')
                                            ->helperText('Tải lên nhiều ảnh định dạng JPG/PNG. Nhấp vào ảnh ngoài client sẽ bật Modal Slider xem phóng to.')
                                            ->image()
                                            ->multiple()
                                            ->reorderable()
                                            ->directory('schools/gallery')
                                            ->disk('public')
                                            ->visibility('public')
                                            ->columnSpanFull(),
                                    ]),
                            ]),

                        // ==============================================================
                        // TAB 2: BAN GIÁM HIỆU
                        // ==============================================================
                        Tab::make('Ban Giám hiệu')
                            ->icon(Heroicon::OutlinedUserGroup)
                            ->schema([
                                Section::make('Danh sách Ban Giám hiệu, Ban Giám đốc & Trưởng khoa')
                                    ->description('Chỉ cần nhập Họ tên và Chức vụ tương ứng (Hiệu trưởng, Hiệu phó, Trưởng khoa...)')
                                    ->schema([
                                        Repeater::make('leaders')
                                            ->label('Danh sách Ban Giám hiệu & Lãnh đạo')
                                            ->addActionLabel('+ Thêm cán bộ lãnh đạo / Trưởng khoa')
                                            ->schema([
                                                TextInput::make('name')
                                                    ->label('Họ và tên')
                                                    ->placeholder('VD: Nguyễn Văn A')
                                                    ->required(),

                                                TextInput::make('position')
                                                    ->label('Chức vụ')
                                                    ->placeholder('VD: Hiệu trưởng, Phó Hiệu trưởng, Trưởng khoa Cơ điện...')
                                                    ->required(),
                                            ])
                                            ->columns(2)
                                            ->defaultItems(0)
                                            ->reorderable()
                                            ->collapsible()
                                            ->itemLabel(fn (array $state): ?string => 
                                                filled($state['name'] ?? null) 
                                                    ? (($state['position'] ?? 'Cán bộ') . ': ' . $state['name']) 
                                                    : 'Cán bộ mới'
                                            ),
                                    ]),
                            ]),

                        // ==============================================================
                        // TAB 3: ĐÀO TẠO
                        // ==============================================================
                        Tab::make('Đào tạo')
                            ->icon(Heroicon::OutlinedAcademicCap)
                            ->schema([
                                Section::make('Các ngành / nghề đào tạo')
                                    ->description('Khai báo danh mục các chuyên ngành trường đang tuyển sinh và đào tạo')
                                    ->schema([
                                        Repeater::make('majorAssignments')
                                            ->label('Danh mục Ngành / Nghề đào tạo')
                                            ->relationship('majorAssignments')
                                            ->addActionLabel('+ Thêm ngành nghề đào tạo')
                                            ->schema([
                                                Select::make('training_major_id')
                                                    ->label('Chuyên ngành / nghề đào tạo')
                                                    ->relationship('trainingMajor', 'name', modifyQueryUsing: fn ($query) => $query->where('is_active', true))
                                                    ->searchable()
                                                    ->getSearchResultsUsing(function (?string $search): array {
                                                        $search = mb_strtolower(trim((string) $search), 'UTF-8');
                                                        $query = \App\Models\TrainingMajor::query()
                                                            ->where('is_active', true);

                                                        if ($search !== '') {
                                                            $query->whereRaw(
                                                                'LOWER(name) COLLATE utf8mb4_bin LIKE ?',
                                                                ["%{$search}%"],
                                                            );
                                                        }

                                                        return $query->orderBy('name')
                                                            ->limit(50)
                                                            ->pluck('name', 'id')
                                                            ->toArray();
                                                    })
                                                    ->optionsLimit(50)
                                                    ->required()
                                                    ->disableOptionsWhenSelectedInSiblingRepeaterItems(),

                                                TextInput::make('annual_quota')
                                                    ->label('Chỉ tiêu tuyển sinh')
                                                    ->numeric()
                                                    ->minValue(0)
                                                    ->default(0)
                                                    ->suffix('SV/năm'),
                                            ])
                                            ->columns(2)
                                            ->defaultItems(0)
                                            ->collapsible()
                                            ->itemLabel(fn (array $state): ?string => 
                                                filled($state['training_major_id'] ?? null)
                                                    ? 'Chuyên ngành đã chọn'
                                                    : 'Ngành đào tạo mới'
                                            ),
                                    ]),

                                Section::make('Quy mô Sinh viên & Hiệu quả đào tạo')
                                    ->description('Các chỉ số sinh viên tuyển sinh, đang học, tốt nghiệp và tỷ lệ việc làm')
                                    ->schema([
                                        Grid::make(4)->schema([
                                            TextInput::make('annual_enrollment')
                                                ->label('Tuyển sinh hàng năm')
                                                ->numeric()
                                                ->default(0)
                                                ->placeholder('Số lượng SV mới'),

                                            TextInput::make('student_count')
                                                ->label('Tổng sinh viên đang học')
                                                ->numeric()
                                                ->default(0)
                                                ->placeholder('Quy mô hiện tại'),

                                            TextInput::make('annual_graduates')
                                                ->label('Tốt nghiệp hàng năm')
                                                ->numeric()
                                                ->default(0)
                                                ->placeholder('Số ra trường/năm'),

                                            TextInput::make('employment_rate')
                                                ->label('Tỷ lệ có việc làm (%)')
                                                ->numeric()
                                                ->step(0.1)
                                                ->suffix('%')
                                                ->placeholder('VD: 92.5'),
                                        ]),
                                    ]),
                            ]),

                        // ==============================================================
                        // TAB 4: GIẢNG VIÊN
                        // ==============================================================
                        Tab::make('Giảng viên')
                            ->icon(Heroicon::OutlinedIdentification)
                            ->schema([
                                Section::make('Quy mô & Tình trạng Thừa / Thiếu giáo viên')
                                    ->description('Quản lý định biên và cân đối nhân lực giảng dạy theo quy định của Sở')
                                    ->schema([
                                        Grid::make(4)->schema([
                                            TextInput::make('teacher_count')
                                                ->label('Tổng số GV/giảng viên')
                                                ->numeric()
                                                ->default(0),

                                            TextInput::make('teacher_quota')
                                                ->label('Định biên được giao')
                                                ->numeric()
                                                ->default(0),

                                            TextInput::make('teachers_shortage')
                                                ->label('Số lượng còn THIẾU')
                                                ->numeric()
                                                ->default(0)
                                                ->extraInputAttributes(['style' => 'color: #dc2626; font-weight: bold;']),

                                            TextInput::make('teachers_surplus')
                                                ->label('Số lượng DÔI DƯ (thừa)')
                                                ->numeric()
                                                ->default(0),
                                        ]),
                                    ]),

                                Section::make('Phân loại Giảng viên theo Ngạch / Hạng')
                                    ->description('Phân loại theo tiêu chuẩn chức danh nghề nghiệp viên chức giảng dạy')
                                    ->schema([
                                        Grid::make(3)->schema([
                                            TextInput::make('faculty_rank_1')
                                                ->label('Giảng viên Loại 1 (Hạng I - Cao cấp)')
                                                ->numeric()
                                                ->default(0)
                                                ->placeholder('VD: 10'),

                                            TextInput::make('faculty_rank_2')
                                                ->label('Giảng viên Loại 2 (Chính - Hạng II)')
                                                ->numeric()
                                                ->default(0)
                                                ->placeholder('VD: 20'),

                                            TextInput::make('faculty_rank_3')
                                                ->label('Giảng viên Hạng III / Giảng viên')
                                                ->numeric()
                                                ->default(0),
                                        ]),
                                    ]),

                                Section::make('Phân loại theo Học vị / Học hàm')
                                    ->description('Số lượng cán bộ giảng dạy có học vị sau đại học')
                                    ->schema([
                                        Grid::make(3)->schema([
                                            TextInput::make('faculty_doctors')
                                                ->label('Tiến sĩ (TS)')
                                                ->numeric()
                                                ->default(0)
                                                ->placeholder('VD: 11'),

                                            TextInput::make('faculty_masters')
                                                ->label('Thạc sĩ (ThS)')
                                                ->numeric()
                                                ->default(0)
                                                ->placeholder('VD: 11'),

                                            TextInput::make('faculty_professors')
                                                ->label('Giáo sư / Phó Giáo sư (GS / PGS)')
                                                ->numeric()
                                                ->default(0),
                                        ]),
                                    ]),
                            ]),

                        // ==============================================================
                        // TAB 5: DOANH NGHIỆP
                        // ==============================================================
                        Tab::make('Doanh nghiệp')
                            ->icon(Heroicon::OutlinedBriefcase)
                            ->schema([
                                Section::make('Doanh nghiệp Liên kết (Slider & Modal đối tác)')
                                    ->description('Khai báo các doanh nghiệp hợp tác thực tập, tuyển dụng. Chọn "Hiện trên Slider" để hiển thị 4-5 doanh nghiệp tiêu biểu.')
                                    ->schema([
                                        Repeater::make('partner_enterprises')
                                            ->label('Danh sách Doanh nghiệp liên kết')
                                            ->addActionLabel('+ Thêm doanh nghiệp liên kết')
                                            ->schema([
                                                TextInput::make('name')
                                                    ->label('Tên doanh nghiệp')
                                                    ->placeholder('VD: Tập đoàn Hyundai Thành Công Ninh Bình')
                                                    ->required()
                                                    ->columnSpan(2),

                                                TextInput::make('cooperation')
                                                    ->label('Nội dung hợp tác')
                                                    ->placeholder('VD: Thực tập sinh, Tuyển dụng kỹ sư...')
                                                    ->columnSpan(2),

                                                FileUpload::make('logo')
                                                    ->label('Logo doanh nghiệp')
                                                    ->image()
                                                    ->directory('enterprises/logos')
                                                    ->disk('public')
                                                    ->visibility('public'),

                                                Toggle::make('is_featured')
                                                    ->label('Hiện trên Slider (Top 4-5)')
                                                    ->default(true)
                                                    ->inline(false),
                                            ])
                                            ->columns(6)
                                            ->defaultItems(0)
                                            ->collapsible()
                                            ->itemLabel(fn (array $state): ?string => $state['name'] ?? 'Doanh nghiệp đối tác'),
                                    ]),
                            ]),
                    ]),
            ]);
    }
}
