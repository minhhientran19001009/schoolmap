<?php

namespace App\Providers\Filament;

use App\Filament\Business\Resources\ManagedWorkforceDemands\ManagedWorkforceDemandResource;
use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Pages\Dashboard;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\View\PanelsRenderHook;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;

class BusinessPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->id('business')
            ->path('doanh-nghiep')
            ->login()
            ->passwordReset()
            ->spa()
            ->colors(['primary' => Color::Purple])
            ->font('Roboto')
            ->brandName('Cổng thông tin Doanh nghiệp')
            ->homeUrl(fn (): string => ManagedWorkforceDemandResource::getUrl())
            ->sidebarCollapsibleOnDesktop()
            ->renderHook(PanelsRenderHook::BODY_START, fn () => view('filament.components.loading-bar'))
            ->discoverResources(
                in: app_path('Filament/Business/Resources'),
                for: 'App\\Filament\\Business\\Resources',
            )
            ->pages([Dashboard::class])
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([Authenticate::class]);
    }
}
